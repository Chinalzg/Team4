<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/6/5 0005
 * Time: 10:45
 */
?>
<center>
    <table border="2">
        <tr>
            <td>ID</td>
            <td>用户名</td>
            <td>密码</td>
            <td>操作</td>
        </tr>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($v['id']); ?></td>
            <td><?php echo e($v['uname']); ?></td>
            <td><?php echo e($v['pwd']); ?></td>
            <td>
                <a href="<?php echo e(action('HomeController@del',['id'=>$v['id']])); ?>">删除</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</center><?php /**PATH E:\htdocs\laravel\resources\views/home/show.blade.php ENDPATH**/ ?>