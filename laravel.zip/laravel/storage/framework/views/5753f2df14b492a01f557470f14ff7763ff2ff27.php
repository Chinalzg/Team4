<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>电子商城后台</title>
        <link rel="stylesheet" href="<?php echo e(URL::asset('static/css/pintuer.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('static/css/admin.css')); ?>">
        <script src="<?php echo e(URL::asset('static/js/jquery.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('static/js/pintuer.js')); ?>"></script>
       
       
    </head>
    <body>
        <?php echo $__env->yieldContent('content'); ?>
        
        
    </body>
</html>
<?php /**PATH E:\htdocs\laravel\Modules\Admin\Providers/../Resources/views/layouts/master.blade.php ENDPATH**/ ?>